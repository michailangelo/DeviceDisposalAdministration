package home.exer2;

public class DisposalPoint {

	private String address;

	public DisposalPoint(String address) {
		super();
		this.address = address;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
