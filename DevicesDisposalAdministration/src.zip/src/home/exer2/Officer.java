package home.exer2;

/**
 *
 * @author Tzeni
 */
public class Officer extends Employee {

    public Officer(String name, String position) {
        super(name, position);

    }

}
